package com.example.whazlansaja

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
