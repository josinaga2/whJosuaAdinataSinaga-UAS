class DataSaya {
  static String nama = "Josua Adinata Sinaga";
  static String gambar = "assets/mahasiswa/josua.jpeg";
}
